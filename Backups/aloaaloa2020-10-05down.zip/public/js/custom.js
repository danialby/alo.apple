

$("#sideBtn").click(function()
{
slide();
});


function slide() {
    if($("#menuSVG").hasClass("rt90"))
    {
        $("#menuSVG").removeClass("rt90");
    }
    else
    {
        $("#menuSVG").addClass("rt90");
    }
    $("#left").toggleClass("opened");
}

$(".myinput").click(function(){
    var el = "#l" + $(this).attr("name");
    $(el).addClass('hidden');
  });
  $(".myinput").blur(function(){
    var el = "#l" + $(this).attr("name");
    if($(this).val() === "")
    $(el).removeClass('hidden');
  });


  $.ajaxSetup({

    headers: {

        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

    }
});


$("#sendReq").click(function(e){
    e.preventDefault();

    var fullname = $("input[name=fullname]").val();
    var email = $("input[name=email]").val();
    var mobile = $("input[name=mobile]").val();
    var modelt = document.getElementsByName("dvt")[0];
    var modell = document.getElementsByName("dvl")[0];
    var model;
    try {
        if(!modelt)
        model = "Other";
        else
        model = modelt.options[modelt.selectedIndex].innerText + " - "+ modell.options[modell.selectedIndex].innerText;
    } catch (error) {
        document.getElementById("failM").style.display = "block";
 }
    var contactType = document.querySelector('input[name="rb"]:checked').value;
    var subject = $("select[name=subject]").val();
    var calldate = $("input[name=idate]").val();
        if(calldate === "")
        calldate = "OYC";
    var details = $("textarea[name=details]").val();


         $.ajax({

       type:'POST',

       url:"/AjaxSend",

       data:{
            fullname:fullname,
            email:email,
            mobile:mobile,
            model:model,
            subject:subject,
            calldate:calldate,
            details:details,
            contactType:contactType
       },

       success:function(data){

          alert(data.success);
       },
            error:function(data)
            {
            console.log(data.responseJSON);
            }
    });
});

