<template>
        <div id="contact-side" class="col-md-4">
                    <p id="ctel" class="contact-head">۰۹۱۰-۱۶۶-۹۰۰۹</p><br />
                    <p id="cemail"><a href="mailto:info@hzk.ir">info@hzk.ir</a></p><br />
                    <p id="cwww"><br /></p><br />
                </div>
</template>

<script>
    export default {
        mounted() {
            console.log('ContactBox mounted.')
        }
    }
</script>
