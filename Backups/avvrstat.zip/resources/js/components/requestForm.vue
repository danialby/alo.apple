<template>
  <div id="orderForm">
    <form id="requestForm">
      <label id="lsubject" class="mylabel">عنوان درخواست :</label>
      <select
        name="subject"
        id="subjselBox"
        class="myinputB"
        v-model="$v.subjV.$model"
        v-on:input="$v.subjV.$touch"
        @blur="$v.subjV.$touch"
        v-bind:class="{error: $v.subjV.$error, dirty: $v.subjV.$dirty && !$v.subjV.$invalid}"
        >
        <option value="" selected disabled hidden>انتخاب کنید...</option>
        <option value="1">مشکلات سخت افزاری | تعمیرات</option>
        <option value="2">مشکلات نرم افزاری |اپل آی دی-برنامه-آپدیت و...</option>
        <option value="3">مشاوره خرید</option>
        <option value="4">سایر</option>
      </select>
      <span class="theFail" v-if="(!$v.subjV.required)">
        <p class="failText">عنوان درخواست را انتخاب کنید</p>
      </span>
      <label id="lfullname" class="mylabel">نام و نام خانوادگی :</label>
      <input
        name="fullname"
        class="myinput"
        type="text"
        v-model="$v.fullV.$model"
        :class="status($v.fullV)"
        @blur="$v.fullV.$touch"
      />
      <span class="theFail" v-if="(!$v.fullV.required)">
        <p class="failText">نام و نام خانوادگی را وارد کنید</p>
      </span>


      <div id="mobilePart">
        <label id="lmobile" class="mylabel">شماره موبایل :</label>
        <input
          name="mobile"
          id="mobTextBox"
          class="myinput"
          placeholder="مثال : 09123456789"
          v-model="$v.mobileV.$model"
          :class="status($v.mobileV)"
          @blur="$v.mobileV.$touch"
          maxlength="13"
          pattern="/^(\+98|0098|98|0)?9\d{9}$/g"
        />
        <span class="theFail" v-if="!$v.mobileV.required">
          <p class="failText">موبایل الزامی است</p>
        </span>
        <span class="theFail" v-if="!$v.mobileV.minLength">
          <p class="failText">تعداد ارقام ۱۱ رقم نیست</p>
        </span>
      </div>


<div id="emailPart">
      <label id="lemail" class="mylabel">ایمیل :</label>
      <input
        name="email"
        id="emailTextBox"
        class="myinput"
        v-model="$v.emailValue.$model"
        :class="status($v.emailValue)"
        @blur="$v.emailValue.$touch"
        placeholder="مثال : info@aloapple.ir"
      />
      <span class="theFail" v-if="!$v.emailValue.required">
        <p class="failText">ایمیل را وارد کنید</p>
      </span>
      <span class="theFail" v-if="!$v.emailValue.email">
        <p class="failText">ایمیل وارد شده معتبر نیست</p>
      </span>

      </div>
      <!-- <div id="otherOptions" class="otherOptions"> -->
      <label id="lmodel" for="devmodel" class="mylabel" v-if="this.subjV < 3 && this.subjV > 0">مدل دستگاه :</label>
      <div id="devmodel" v-if="this.subjV < 3 && this.subjV > 0">
        <!-- <autocomplete :search="search"></autocomplete> -->
        <!-- <input name="model" id="modelTextBox" class="myinput" placeholder="مثال : iPhone 6s" /> -->
        <!-- <ts></ts> -->
        <select v-model="$v.selectedType.$model" class="deviceList" name="dvt"
        v-on:input="$v.selectedType.$touch"
        @blur="$v.selectedType.$touch"
        v-bind:class="{error: $v.selectedType.$error, dirty: $v.selectedType.$dirty && !$v.selectedType.$invalid}">
          <option v-for="devType in devType" :value="devType">{{ devType.label }}</option>
        </select>

        <select v-model="selectedOption" class="deviceList" name="dvl"
                v-on:input="$v.selectedOption.$touch"
        @blur="$v.selectedOption.$touch"
        v-bind:class="{error: $v.selectedOption.$error, dirty: $v.selectedOption.$dirty && !$v.selectedOption.$invalid}">
          <option v-for="option in selectedType.options">{{ option }}</option>
        </select>
      </div>
                    <span id="failM" class="theFail" v-if="!$v.selectedOption.required">
        <p class="failText">مدل دستگاه الزامی است</p>
      </span>
        <label id="lmodel" class="mylabel">نحوه پاسخگویی :</label>



            <div id="contactType">

        <input name="rb" type="radio" value="Call" id="callCheckBox" class="radioB" checked />
        <label for="callCheckBox">تماس تلفنی</label>
        <input name="rb" type="radio" value="Email" id="emailcheckBox" class="radioB" />
        <label for="emailcheckBox">ایمیل</label>
        <input name="rb" type="radio" id="ticketCheckbox" value="ticket" class="radioB" disabled/>
        <label for="ticketCheckbox">تیکت (بزودی)</label>
      </div>




      <label id="ltime" class="mylabel"> زمان تماس <br />پیشنهادی :</label>
      <date-picker
        name="idate"
        v-model="datetime"
        format="jYYYY/jMM/jDD HH:mm"
        inputClass="form-control myinputB"
        placeholder="..."
        color="#00acc1"
        type="datetime"
        append-to="#left"
      ></date-picker>
      <!-- </div> -->
      <label id="ldetails" class="mylabel">خلاصه درخواست :</label>
      <textarea
       name="details"
       id="detTextBox"
       class="myinput"
       v-model="$v.detV.$model"
        :class="status($v.detV)"
        @blur="$v.detV.$touch"
        ></textarea>
              <span class="theFail" v-if="!$v.detV.required">
        <p class="failText">سوال خود را بنویسید...</p>
      </span>
      <br />
      <!-- <input name="regcode" id="codeTextBox" class="codeInput" /> -->
      <input
        id="sendReq"
        class="myButton btn-submit"
        type="submit"
        value="ثبت درخواست"
        @click="validate"
      />

      <input type="hidden" name="_token" :value="csrf" />
    </form>
  </div>
</template>

<script>
import {
  required,
  email,
  minLength,
  requiredIf
} from "vuelidate/lib/validators";
export default {
  data() {
    return {
      csrf: document
        .querySelector('meta[name="csrf-token"]')
        .getAttribute("content"),
        picked:'',
      fullV: "",
      mobileV: "",
      emailValue: "",
      subjV: "",
      datetime: "",
      detV:"",
      devType: [
        {
          label: "iPhone",
          options: [
            "11 Pro Max",
            "11 Pro",
            "11",
            "Xʀ",
            "Xs Max",
            "Xs",
            "X",
            "8 Plus",
            "8",
            "7 Plus",
            "7",
            "SE",
            "6S Plus",
            "6S",
            "6 Plus",
            "6",
            "5S",
            "5C",
            "4S",
            "4"
          ]
        },
        {
          label: "iPad",
          options: ["iPad", "Pro", "Air", "Mini"]
        },
        {
          label: "MacBook",
          options: ["Starbucks", "Dunkin Donuts", "Gross Hotel Room"]
        },
        {
          label: "MacBook Pro",
          options: ["Starbucks", "Dunkin Donuts", "Gross Hotel Room"]
        },
        {
          label: "Apple Watch",
          options: ["1 Series", "2 Series", "3 Series", "4 Series", "5 Series"]
        }
      ],
      selectedType: -1,
       selectedOption:''
    };
  },

  validations: {
    mobileV: {
      required,
      minLength: minLength(11)
    },
    fullV: {
      required
    },
    emailValue: {
      required,
      email
    },
    subjV: {
      required
    },
    detV:{
        required
    },
    selectedType:{
        required
    },
    selectedOption:{
        required
    }
  },
  methods: {
    status(validation) {
      return {
        error: validation.$error,
        dirty: validation.$dirty
      };
    },
    validate() {
      this.$v.$touch(); //it will validate all fields
      if (!this.$v.$invalid) {
        //invalid, becomes true when a validations return false
        //you dont have validation error.So do what u want to do here
      }
    },
  }
};
</script>
