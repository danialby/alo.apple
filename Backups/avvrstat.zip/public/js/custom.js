

$("#sideBtn").click(function()
{
slide();
});


function slide() {
    if($("#menuSVG").hasClass("rt90"))
    {
        $("#menuSVG").removeClass("rt90");
    }
    else
    {
        $("#menuSVG").addClass("rt90");
    }
    $("#left").toggleClass("opened");
}

function accColor(c) {
    var a = document.body.classList.length;
    if(a>0){
    var accent = document.body.classList[a-1].toString();
    $('body').removeClass(accent);
    $('body').addClass(c);
    }
}


// Restricts input for the given textbox to the given inputFilter.
// function setInputFilter(textbox, inputFilter) {
//     ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop"].forEach(function(event) {
//       textbox.addEventListener(event, function() {
//         if (inputFilter(this.value)) {
//           this.oldValue = this.value;
//           this.oldSelectionStart = this.selectionStart;
//           this.oldSelectionEnd = this.selectionEnd;
//         } else if (this.hasOwnProperty("oldValue")) {
//           this.value = this.oldValue;
//           this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
//         } else {
//           this.value = "";
//         }
//       });
//     });
//   }


//   // Install input filters.
// setInputFilter(document.getElementById("intTextBox"), function(value) {
//     return /^-?\d*$/.test(value); });
//   setInputFilter(document.getElementById("uintTextBox"), function(value) {
//     return /^\d*$/.test(value); });
//   setInputFilter(document.getElementById("intLimitTextBox"), function(value) {
//     return /^\d*$/.test(value) && (value === "" || parseInt(value) <= 500); });
//   setInputFilter(document.getElementById("floatTextBox"), function(value) {
//     return /^-?\d*[.,]?\d*$/.test(value); });
//   setInputFilter(document.getElementById("currencyTextBox"), function(value) {
//     return /^-?\d*[.,]?\d{0,2}$/.test(value); });
//   setInputFilter(document.getElementById("latinTextBox"), function(value) {
//     return /^[a-z]*$/i.test(value); });
//   setInputFilter(document.getElementById("hexTextBox"), function(value) {
//     return /^[0-9a-f]*$/i.test(value); });


$(".myinput").click(function(){
    var el = "#l" + $(this).attr("name");
    $(el).addClass('hidden');
  });
  $(".myinput").blur(function(){
    var el = "#l" + $(this).attr("name");
    if($(this).val() == "")
    $(el).removeClass('hidden');
  });


  $.ajaxSetup({

    headers: {

        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

    }

});
$("#sendReq").click(function(e){
    e.preventDefault();

    var fullname = $("input[name=fullname]").val();
    var email = $("input[name=email]").val();
    var mobile = $("input[name=mobile]").val();
    var modelt = document.getElementsByName("dvt")[0];
    var modell = document.getElementsByName("dvl")[0];
    var model;
    try {
        if(!modelt)
        model = "Other";
        else
        model = modelt.options[modelt.selectedIndex].innerText + " - "+ modell.options[modell.selectedIndex].innerText;
    } catch (error) {
        document.getElementById("failM").style.display = "block";
 }
    contactType = document.querySelector('input[name="rb"]:checked').value;
    var subject = $("select[name=subject]").val();
    var calldate = $("input[name=idate]").val();
        if(calldate == "")
        calldate = "OYC";
    var details = $("textarea[name=details]").val();


         $.ajax({

       type:'POST',

       url:"/",

       data:{
            fullname:fullname,
            email:email,
            mobile:mobile,
            model:model,
            subject:subject,
            calldate:calldate,
            details:details,
            contactType:contactType
       },

       success:function(data){

          alert(data.success);
          $("#requestForm")[0].reset();
       },
            error:function(data)
            {
            console.log(data.responseJSON);
            }
    });
});
$("#reqStat").click(function(e){
    e.preventDefault();
statfetch("33");
});
$(".btn-submit").click(function(e){
    e.preventDefault();

    var fullname = $("input[name=fullname]").val();
    var email = $("input[name=email]").val();
    var mobile = $("input[name=mobile]").val();
    var modelt = document.getElementsByName("dvt")[0];
    var modell = document.getElementsByName("dvl")[0];
    var model;
    try {
        if(!modelt)
        model = "Other";
        else
        model = modelt.options[modelt.selectedIndex].innerText + " - "+ modell.options[modell.selectedIndex].innerText;
    } catch (error) {
        document.getElementById("failM").style.display = "block";
 }
    contactType = document.querySelector('input[name="rb"]:checked').value;
    var subject = $("select[name=subject]").val();
    var calldate = $("input[name=idate]").val();
        if(calldate == "")
        calldate = "OYC";
    var details = $("textarea[name=details]").val();


         $.ajax({

       type:'POST',

       url:"/",

       data:{
            fullname:fullname,
            email:email,
            mobile:mobile,
            model:model,
            subject:subject,
            calldate:calldate,
            details:details,
            contactType:contactType
       },

       success:function(data){

          alert(data.success);
          $("#requestForm")[0].reset();
       },
            error:function(data)
            {
            console.log(data.responseJSON);
            }
    });
});

function statfetch(id)
{
    $("#stat").load("/Status/{"+id+"}");
}
