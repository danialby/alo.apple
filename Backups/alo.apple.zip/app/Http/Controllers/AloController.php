<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\irequests;
class AloController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
        public function index()
        {
            return view('aa');
        }
        public function status()
        {
            //
            return view('index');
        }
        public function reqList()
        {
            //
            $reqs = irequests::all();

            return view('reqList',compact('reqs'));
        }
            /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\Request
     * @return \Illuminate\Http\Response
     */
       /**

     * Create a new controller instance.

     *

     * @return void

     */

   
}
