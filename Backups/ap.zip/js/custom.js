
function slide() {
    if($("#menuSVG").hasClass("rt90"))
    {
        $("#menuSVG").removeClass("rt90");
    }
    else
    {
        $("#menuSVG").addClass("rt90");
    }
    $("#menuBox").toggleClass("closed");
}

function accColor(c) {
    var a = document.body.classList.length;
    if(a>0){
    var accent = document.body.classList[a-1].toString();
    $('body').removeClass(accent);
    $('body').addClass(c);
    }
}


// Restricts input for the given textbox to the given inputFilter.
// function setInputFilter(textbox, inputFilter) {
//     ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop"].forEach(function(event) {
//       textbox.addEventListener(event, function() {
//         if (inputFilter(this.value)) {
//           this.oldValue = this.value;
//           this.oldSelectionStart = this.selectionStart;
//           this.oldSelectionEnd = this.selectionEnd;
//         } else if (this.hasOwnProperty("oldValue")) {
//           this.value = this.oldValue;
//           this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
//         } else {
//           this.value = "";
//         }
//       });
//     });
//   }


//   // Install input filters.
// setInputFilter(document.getElementById("intTextBox"), function(value) {
//     return /^-?\d*$/.test(value); });
//   setInputFilter(document.getElementById("uintTextBox"), function(value) {
//     return /^\d*$/.test(value); });
//   setInputFilter(document.getElementById("intLimitTextBox"), function(value) {
//     return /^\d*$/.test(value) && (value === "" || parseInt(value) <= 500); });
//   setInputFilter(document.getElementById("floatTextBox"), function(value) {
//     return /^-?\d*[.,]?\d*$/.test(value); });
//   setInputFilter(document.getElementById("currencyTextBox"), function(value) {
//     return /^-?\d*[.,]?\d{0,2}$/.test(value); });
//   setInputFilter(document.getElementById("latinTextBox"), function(value) {
//     return /^[a-z]*$/i.test(value); });
//   setInputFilter(document.getElementById("hexTextBox"), function(value) {
//     return /^[0-9a-f]*$/i.test(value); });


$(".myinput").click(function(){
    var el = "#l" + $(this).attr("name");
    $(el).addClass('hidden');
  });
  $(".myinput").blur(function(){
    var el = "#l" + $(this).attr("name");
    if($(this).val() == "")
    $(el).removeClass('hidden');
  });


  $.ajaxSetup({

    headers: {

        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

    }

});
$(".btn-submit").click(function(e){
    e.preventDefault();
    var fullname = $("input[name=fullname]").val();
    var email = $("input[name=email]").val();
    var mobile = $("input[name=mobile]").val();
    var model = $("input[name=model]").val();
    var subject = $("select[name=subject]").val();
    var calldate = $("input[name=idate]").val();
    var calltime = $("input[name=itime]").val();
    var details = $("textarea[name=details]").val();
         
         
         $.ajax({

       type:'POST',

       url:"/sendReq",

       data:{
            fullname:fullname,
            email:email,
            mobile:mobile,
            model:model,
            subject:subject,
            calldate:calldate,
            calltime:calltime,
            details:details
       },

       success:function(data){

          alert(data.success);

       },
            error:function(data)
            {
            console.log(data.responseJSON);
            }
    });
});

// $(document).ready(function(){

//     $('#reqForm').parsley();
   
//     $('#sendReq').on('click', function(event){
//      event.preventDefault();
//          var fullname = $("input[name=fullname]").val();
//     var email = $("input[name=email]").val();
//     var mobile = $("input[name=mobile]").val();
//     var model = $("input[name=model]").val();
//     var subject = $("select[name=subject]").val();
//     var calldate = $("input[name=idate]").val();
//     var calltime = $("input[name=itime]").val();
//     var details = $("textarea[name=details]").val();
//      if ($('#reqForm').length > 0 ) {
//      if($('#reqForm').parsley().isValid())
//      {
//       $.ajax({
//        url: '/sendReq',
//        method:"POST",
//        data:{
//         fullname:fullname,
//         email:email,
//         mobile:mobile,
//         model:model,
//         subject:subject,
//         calldate:calldate,
//         calltime:calltime,
//         details:details
//        },
//        dataType:"json",
//        beforeSend:function()
//        {
//         $('.btn-submit').attr('disabled', 'disabled');
//         $('.btn-submit').val('Submitting...');
//        },
//        success:function(data)
//        {
//         $('#reqForm')[0].reset();
//         $('#reqForm').parsley().reset();
//         $('.btn-submit').attr('disabled', false);
//         $('.btn-submit').val('Submit');
//         alert(data.success);
//        },
//        error:function(data)
//        {
//            alert(data.error);
//        }
//       });
//      }
//     }
//     });
   
//    });