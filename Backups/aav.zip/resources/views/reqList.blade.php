@extends('layouts.aloapple')
@section('content')
<div class="container contact">
    <div class="row justify-content-center">
        <div id="contact-form" class="col-md-8">
            <div class="card mycard wh">
                <div class="card-header">لیست درخواستها</div>
                <div class="card-body">
@foreach ($reqs as $req)
<li> {{ $req }}  </li>
@endforeach

                </div>
               
            </div>
        </div>
    </div>
    @if (count($errors) > 0)
                        <div class="alert alert-danger">
                            <ul>
                            @foreach($errors->all() as $error)
                                <li>{{$error}}</li>  
                            @endforeach
                            </ul>
                        </div>
                    @endif
                    @if(\Session::has('success'))
                    <div class="alert alert-success">
                        <p>
                        {{\Session::get('success')}}
                        Data added Successfully!
                        </p>
                    </div>
                    @endif
</div>
@endsection
