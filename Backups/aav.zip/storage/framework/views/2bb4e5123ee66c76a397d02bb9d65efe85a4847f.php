<?php $__env->startSection('content'); ?>
<div class="container contact">
    <div class="row justify-content-center">
        <div id="contact-form" class="col-md-12 col-lg-11 col-sm-12">
            <div class="card mycard">
                <!-- <div class="card-header">تماس با ما</div> -->
                <div class="card-body">
<reqform></reqform>
                </div>
               
            </div>
        </div>
                <!-- <contact-box></contact-box> -->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.aloapple', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bitnami\wampstack-7.2.26-0\apache2\htdocs\alo.apple\resources\views\index.blade.php ENDPATH**/ ?>