<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravella') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
    <script src="{{ asset('js/custom.js') }}" defer></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/custom.css') }}" rel="stylesheet">
</head>

<body>
                    <a id="sideBtn" href="#">
                    <svg class="i-ellipsis-horizontal LthreeDots rt90" id="menuSVG" viewBox="0 0 32 32" width="24" height="24"
                        fill="black" stroke="currentcolor" stroke-linecap="round" stroke-linejoin="round"
                        stroke-width="1">
                        <circle cx="7" cy="16" r="2"></circle>
                        <circle cx="16" cy="16" r="2"></circle>
                        <circle cx="25" cy="16" r="2"></circle>
                    </svg></a>
    <div id="right">
        <div id="app">
            <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
                <div class="container">

                    <!-- <button class="navbar-toggler" type="button" data-toggle="collapse"
                        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                        <span class="navbar-toggler-icon"></span>
                    </button> -->

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <!-- Left Side Of Navbar -->
                        <ul class="navbar-nav mr-auto">

                        </ul>


                    </div>
                </div>
            </nav>

            <!-- <div id="menuBox">
<div class="col-12"></div>
<div class="col-12"></div>
<div class="col-12"></div>
</div> -->
            <main class="py-4">
                @yield('content')
            </main>
        </div>
    </div>
    <div id="left">
        <div id="left-top">
        <div id="aa-icon"></div>
            <div id="aa-logo"></div>
        </div>
        <div id="left-bottom">
            <div id="insta">@alo.apple</div>
            <div id="bottom">
                <div id="tehran">
                <h6><strong>تهران :</strong></h6>
                    <p class="addr">
                        میدان تجریش - مجتمع تجاری ارگ - طبقه منفی ۱ - واحد ۱۰۳
                              <p class="phone">
                            <span class="lindent">+9821</span>  22396434
                                    </p>
                                    <p class="phone nopref">
                                    22397570
                                    </p>
                    </p>

                </div>
                <br>
                <div id="ahwaz">
                <h6><strong>اهواز :</strong></h6>
                    <p class="addr">
                    <strong>زیتون کارمندی</strong> - خ حجت - سیتی سنتر مهزیار
                    <p class="phone ">
                        <span class="lindent">+9861</span>  34425252-3
                        </p>
                    </p>
                    <p class="addr">
                    <strong>کیانپارس</strong> - نبش خ ۳ شرقی - جنب بازار مرکزی
                    <p class="phone nopref">
                        33920043-4
                        </p>
                    </p>
                    <p class="addr">
                    <strong>گلستان</strong> - خ فروردین - روبروی مجتمع تفریحی ساحل
                    <p class="phone nopref">
                        33743336
                        </p>
                    </p>
                    <div id="ahwaznum">



               </div>
                </div>

            </div>

            </div>
        </div>
    </div>
</body>

</html>
