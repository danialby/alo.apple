<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Auth::routes();
Route::get('/', 'AloController@index')->name('home');
// Route::get('/Dashboard', 'HomeController@dashboard')->name('dashboard');
// Route::get('/indexa','AloController@home');
Route::get('/reqList','AloController@reqList');
Route::post('/sendReq', 'AjaxController@ajaxRequestPost');
