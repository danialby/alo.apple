<template>
    <div id="orderForm">
        <form >
            <p class="formHead">درخواست خود را از طریق فرم زیر به اطلاع تیم ما برسانید</p>

            <label id="lsubject" class="mylabel">عنوان درخواست :</label>
            <select name="subject" id="subjselBox" class="myinputB">
                <option value="none" selected disabled hidden>انتخاب کنید...</option>
                <option value="1">مشاوره خرید</option>
                <option value="2">مشکلات سخت افزاری | تعمیرات</option>
                <option value="2">مشکلات نرم افزاری |اپل آی دی-برنامه-آپدیت و...</option>
                <option value="3">سایر</option>
            </select>

            <label id="lfullname" class="mylabel">نام و نام خانوادگی :</label>
            <input name="fullname" class="myinput" type="text" v-model="$v.fullV.$model" :class="status($v.fullV)" @blur="$v.fullV.$touch"/>
            <span class="theFail" v-if="(!$v.fullV.required)">
                <p class="failText">نام و نام خانوادگی را وارد کنید</p>
            </span>
            <br />
            <label id="lmobile" class="mylabel">شماره موبایل :</label>
            <input name="mobile" id="mobTextBox" class="myinput" placeholder="مثال : 09123456789" v-model="$v.mobileV.$model" :class="status($v.mobileV)" @blur="$v.mobileV.$touch"
                maxlength="13" pattern="/^(\+98|0098|98|0)?9\d{9}$/g" />
            <span class="theFail" v-if="!$v.mobileV.required">
                <p class="failText">موبایل الزامی است</p>
            </span>
            <span class="theFail" v-if="!$v.mobileV.minLength">
                <p class="failText">تعداد ارقام ۱۱ رقم نیست</p>
            </span>
            <br />
            <label id="lemail" class="mylabel">ایمیل :</label>
            <input name="email" id="emailTextBox" class="myinput" v-model="$v.emailValue.$model" :class="status($v.emailValue)" @blur="$v.emailValue.$touch" placeholder="مثال :‌ info@aloapple.ir"/>
            <span class="theFail" v-if="!$v.emailValue.required">
                <p class="failText">ایمیل را وارد کنید</p>
            </span>
            <span class="theFail" v-if="!$v.emailValue.email">
                <p class="failText">ایمیل وارد شده معتبر نیست</p>
            </span>
            <div id="otherOptions" class="otherOptions">
                <label id="lmodel" class="mylabel">مدل دستگاه :</label>
                <!-- <autocomplete :search="search"></autocomplete> -->
                <input name="model" id="modelTextBox" class="myinput" placeholder="مثال : iPhone 6s" />
                <br />

                <br />

                <label id="ltime" class="mylabel">زمان تماس :</label>
                <date-picker name="idate" v-model="date" format="jYYYY/jMM/jDD" inputClass="form-control myinputB"
                    placeholder="تاریخ..." color="#00acc1" autoSubmit="true"></date-picker>
                <date-picker name="itime" v-model="time" type="time" initial-value="20:45" placeholder="ساعت..."
                    format="HH:mm" />
                <br />
            </div>
            <label id="ldetails" class="mylabel">خلاصه درخواست :</label>
            <textarea name="details" id="detTextBox" class="myinput" rows="5"></textarea>
            <br />
            <!-- <input name="regcode" id="codeTextBox" class="codeInput" /> -->
            <input id="sendReq" class="myButton btn-submit" type="submit" value="ثبت درخواست" />

            <input type="hidden" name="_token" :value="csrf" />
        </form>
    </div>
</template>

<script>
    import {  required,email,minLength  } from "vuelidate/lib/validators";
    export default {
        data() {
            return {
                csrf: document
                    .querySelector('meta[name="csrf-token"]')
                    .getAttribute("content"),
                fullV: "",
                mobileV: "",
                emailValue: ""
            }
        },

        validations: {
            mobileV: {
                required,
                minLength: minLength(11)
            },
            fullV: {
                required
            },
            emailValue: {
                required,
                email
            }
        },
        methods: {
  	status(validation) {
    	return {
      	error: validation.$error,
        dirty: validation.$dirty
      }
    }
  }
    }

</script>
