


@extends('layouts.aloapple')

@section('content')
<div class="container contact">
    <div class="row justify-content-center">
        <div id="order" class="col-md-12 col-lg-11 col-sm-12">
            <div class="card mycard">
                <!-- <div class="card-header">تماس با ما</div> -->
                <div class="card-body">
<reqform></reqform>
                </div>

            </div>
        </div>
                <!-- <contact-box></contact-box> -->
    </div>
</div>

@endsection
