<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card mycard">
                <div class="card-header"><?php echo e(__('ثبت نام خود را محرز کنید')); ?></div>

                <div class="card-body">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('لینک احراز هویت جدید برای شما ارسال شد')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('قبل از شروع لینک احراز هویت را تایید کنید)); ?>

                    <?php echo e(__('اگر ایمیل دریافت نکرده اید')); ?>,
                    <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('دوباره ارسال می کنیم')); ?></button>.
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Tapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> ?><?php /**PATH C:\Bitnami\wampstack-7.2.26-0\apache2\htdocs\alo.apple\resources\views\auth\verify.blade.php ENDPATH**/ ?>