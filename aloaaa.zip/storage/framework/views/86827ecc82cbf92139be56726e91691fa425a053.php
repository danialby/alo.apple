<?php $__env->startSection('content'); ?>
<div class="container contact">
    <div class="row justify-content-center">
        <div id="contact-form" class="col-md-8">
            <div class="card mycard wh">
                <div class="card-header">لیست درخواستها</div>
                <div class="card-body">
<?php $__currentLoopData = $reqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> <?php echo e($req); ?>  </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
               
            </div>
        </div>
    </div>
    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php if(\Session::has('success')): ?>
                    <div class="alert alert-success">
                        <p>
                        <?php echo e(\Session::get('success')); ?>

                        Data added Successfully!
                        </p>
                    </div>
                    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.aloapple', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bitnami\wampstack-7.2.26-0\apache2\htdocs\alo.apple\resources\views/reqList.blade.php ENDPATH**/ ?>